import os
import json
import boto3
from typing import List, Dict

# ==============================
# Configuration
# ==============================

AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
MODEL_ID = "amazon.nova-lite-v1:0"

bedrock = boto3.client("bedrock-runtime", region_name=AWS_REGION)


# ==============================
# Simple Tool Example
# ==============================

def get_current_time() -> str:
    from datetime import datetime
    return datetime.utcnow().isoformat() + " UTC"


TOOLS = {
    "get_current_time": get_current_time
}


# ==============================
# Agent Core Logic
# ==============================

class SimpleStrandsAgent:
    def __init__(self):
        self.system_prompt = (
            "You are a helpful AI agent. "
            "If you need the current time, respond exactly with:\n"
            '{"tool": "get_current_time"}'
        )
        self.conversation: List[Dict] = []

    def _call_model(self, messages: List[Dict]) -> str:
        body = {
            "messages": messages,
            "system": self.system_prompt,
            "inferenceConfig": {
                "maxTokens": 500,
                "temperature": 0.5,
            }
        }

        response = bedrock.invoke_model(
            modelId=MODEL_ID,
            body=json.dumps(body),
            contentType="application/json",
            accept="application/json",
        )

        result = json.loads(response["body"].read())
        return result["output"]["message"]["content"][0]["text"]

    def run(self, user_input: str) -> str:
        self.conversation.append({
            "role": "user",
            "content": [{"text": user_input}]
        })

        model_response = self._call_model(self.conversation)

        # Attempt structured tool call
        try:
            parsed = json.loads(model_response)
            if "tool" in parsed and parsed["tool"] in TOOLS:
                tool_result = TOOLS[parsed["tool"]]()
                return f"(Tool Used) Current Time: {tool_result}"
        except json.JSONDecodeError:
            pass

        return model_response


# ==============================
# Lambda / AgentCore Entry Point
# ==============================

def handler(event, context):
    """
    Expected event format:
    {
        "input": "User message here"
    }
    """

    try:
        agent = SimpleStrandsAgent()
        user_input = event.get("input", "")

        response = agent.run(user_input)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "response": response
            })
        }

    except Exception as e:
        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": str(e)
            })
        }
